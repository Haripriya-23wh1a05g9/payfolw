# payflow_project
A web application for managing employee information, leave tracking, and payroll processing, designed for HR automation and organizational efficiency.
