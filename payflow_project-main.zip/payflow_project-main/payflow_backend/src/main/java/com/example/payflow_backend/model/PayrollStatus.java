package com.example.payflow_backend.model;

public enum PayrollStatus {
    PENDING,
    PROCESSED,
    COMPLETED,
    CANCELLED
}
