package com.example.payflow_backend.model;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}
